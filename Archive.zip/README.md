# ralph-trader

## Quickstart

1) Run one-time bootstrap to scaffold the harness:

```bash
./plans/bootstrap.sh
```

2) See `plans/README.md` for the harness workflow entrypoints.
